package lemurproject.indri;

import java.util.Map;

/**
 * ConflationPattern
 *
 * 26 Sept 2005 -- dmf
 */

public class ConflationPattern {
  public String tag_name;
  public String attribute_name;
  public String value;
}
