package lemurproject.indri;

public class TagExtent {
    public String name;
    public int begin;
    public int end;
}
