package lemurproject.indri;

public class QueryResults {
    public double parseTime;
    public double executeTime;
    public double documentsTime;
    public int estimatedMatches;
    public QueryResult[] results;
}
