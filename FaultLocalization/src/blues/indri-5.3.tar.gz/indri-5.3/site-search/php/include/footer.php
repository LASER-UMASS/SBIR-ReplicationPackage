<!-- placeholder footer -->
<div id="footer">
</div>